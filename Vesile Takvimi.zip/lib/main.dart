import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:geomag/geomag.dart';
import 'package:geolocator/geolocator.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import 'app_storage.dart';
import 'daily_content.dart';
import 'onboarding.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const VesileTakvimiApp());
}

class VesileTakvimiApp extends StatelessWidget {
  const VesileTakvimiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Vesile Takvimi',
      theme: ThemeData(
        useMaterial3: false,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xff9c8455),
          brightness: Brightness.light,
          surface: const Color(0xfff7f5f0),
        ),
        scaffoldBackgroundColor: const Color(0xfff7f5f0),
        fontFamily: 'Inter',
        appBarTheme: const AppBarTheme(
          elevation: 0,
          backgroundColor: Color(0xfff7f5f0),
          foregroundColor: Color(0xff1e1a17),
          iconTheme: IconThemeData(color: Color(0xff1e1a17)),
          titleTextStyle: TextStyle(
            color: Color(0xff1e1a17),
            fontFamily: 'Inter',
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
        ),
        textTheme: const TextTheme(
          titleLarge: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            height: 1.2,
          ),
          titleMedium: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          bodyMedium: TextStyle(
            fontSize: 15,
            height: 1.48,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      home: const AppBootstrap(),
    );
  }
}

class AppBootstrap extends StatefulWidget {
  const AppBootstrap({super.key});

  @override
  State<AppBootstrap> createState() => _AppBootstrapState();
}

class _AppBootstrapState extends State<AppBootstrap> {
  final _storage = AppStorageService();
  bool? _onboardingCompleted;
  bool? _legalAcceptanceCompleted;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final results = await Future.wait([
      _storage.isOnboardingCompleted(),
      _storage.isLegalAcceptanceCompleted(),
      Future<void>.delayed(const Duration(milliseconds: 1600)),
    ]);
    if (!mounted) return;
    setState(() {
      _onboardingCompleted = results[0] as bool;
      _legalAcceptanceCompleted = results[1] as bool;
    });
  }

  Future<void> _completeOnboarding() async {
    await _storage.completeOnboarding();
    await _storage.completeLegalAcceptance();
    if (!mounted) return;
    setState(() {
      _onboardingCompleted = true;
      _legalAcceptanceCompleted = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_onboardingCompleted == null || _legalAcceptanceCompleted == null) {
      return const _SplashScreen();
    }
    if (!_onboardingCompleted!) {
      return OnboardingScreen(onCompleted: _completeOnboarding);
    }
    if (!_legalAcceptanceCompleted!) {
      return LegalAcceptanceScreen(onCompleted: _completeOnboarding);
    }
    return const PrayerHomePage();
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xfff5f1e8),
    body: Center(
      child: Image.asset(
        'assets/images/vesile_logo_transparent.png',
        width: 245,
        height: 245,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) => const SizedBox(
          width: 245,
          height: 245,
          child: Icon(
            Icons.mosque_outlined,
            size: 96,
            color: Color(0xffb18d4f),
          ),
        ),
      ),
    ),
  );
}

class PrayerHomePage extends StatefulWidget {
  const PrayerHomePage({super.key});

  @override
  State<PrayerHomePage> createState() => _PrayerHomePageState();
}

class _PrayerHomePageState extends State<PrayerHomePage> {
  static const _green = Color(0xff9c8455);
  static const _cities = <String>[
    'Adana',
    'Adıyaman',
    'Afyonkarahisar',
    'Ağrı',
    'Aksaray',
    'Amasya',
    'Ankara',
    'Antalya',
    'Ardahan',
    'Artvin',
    'Aydın',
    'Balıkesir',
    'Bartın',
    'Batman',
    'Bayburt',
    'Bilecik',
    'Bingöl',
    'Bitlis',
    'Bolu',
    'Burdur',
    'Bursa',
    'Çanakkale',
    'Çankırı',
    'Çorum',
    'Denizli',
    'Diyarbakır',
    'Düzce',
    'Edirne',
    'Elazığ',
    'Erzincan',
    'Erzurum',
    'Eskişehir',
    'Gaziantep',
    'Giresun',
    'Gümüşhane',
    'Hakkari',
    'Hatay',
    'Iğdır',
    'Isparta',
    'İstanbul',
    'İzmir',
    'Kahramanmaraş',
    'Karabük',
    'Karaman',
    'Kars',
    'Kastamonu',
    'Kayseri',
    'Kırıkkale',
    'Kırklareli',
    'Kırşehir',
    'Kilis',
    'Kocaeli',
    'Konya',
    'Kütahya',
    'Malatya',
    'Manisa',
    'Mardin',
    'Mersin',
    'Muğla',
    'Muş',
    'Nevşehir',
    'Niğde',
    'Ordu',
    'Osmaniye',
    'Rize',
    'Sakarya',
    'Samsun',
    'Siirt',
    'Sinop',
    'Sivas',
    'Şanlıurfa',
    'Şırnak',
    'Tekirdağ',
    'Tokat',
    'Trabzon',
    'Tunceli',
    'Uşak',
    'Van',
    'Yalova',
    'Yozgat',
    'Zonguldak',
  ];

  static const _prayerInfo = <String, (IconData, String)>{
    'İmsak': (Icons.dark_mode_outlined, 'Sabah başlangıcı'),
    'Güneş': (Icons.wb_twilight_outlined, 'Güneş doğuşu'),
    'Öğle': (Icons.light_mode_outlined, 'Öğle vakti'),
    'İkindi': (Icons.wb_cloudy_outlined, 'İkindi vakti'),
    'Akşam': (Icons.nights_stay_outlined, 'Akşam vakti'),
    'Yatsı': (Icons.star_outline_rounded, 'Gece vakti'),
  };

  final _api = PrayerApi();
  final _storage = AppStorageService();
  late Future<DailyReligiousContent> _dailyContent;
  Map<String, String> _times = {};
  String _location = 'Konum seçilmedi';
  String _date = 'Bugünün vakitleri';
  String _hijriDate = '';
  double? _latitude;
  double? _longitude;
  String? _error;
  bool _loading = false;
  Timer? _timer;
  Timer? _dailyContentTimer;
  Duration _remaining = Duration.zero;
  String _nextPrayer = '—';

  @override
  void initState() {
    super.initState();
    _dailyContent = DailyContentService().contentFor(DateTime.now());
    _scheduleDailyContentRefresh();
    _initializeHome();
    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) => _updateCountdown(),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _dailyContentTimer?.cancel();
    super.dispose();
  }

  void _scheduleDailyContentRefresh() {
    _dailyContentTimer?.cancel();
    final now = DateTime.now();
    final nextMidnight = DateTime(now.year, now.month, now.day + 1);
    _dailyContentTimer = Timer(nextMidnight.difference(now), () {
      if (mounted) {
        setState(() {
          _dailyContent = DailyContentService().contentFor(DateTime.now());
        });
      }
      _scheduleDailyContentRefresh();
    });
  }

  Future<void> _initializeHome() async {
    final cached = await _storage.loadPrayerCache();
    if (cached != null && mounted) _restoreCache(cached);
    final savedLocation = await _storage.loadLocation();
    final selectionCompleted = await _storage.isLocationSelectionCompleted();
    if (!mounted) return;
    if (!selectionCompleted || savedLocation == null) {
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => _showLocationChoice(requiredSelection: true),
      );
      return;
    }
    if (savedLocation.automatic &&
        savedLocation.latitude != null &&
        savedLocation.longitude != null) {
      await _loadCoordinates(
        savedLocation.latitude!,
        savedLocation.longitude!,
        persist: false,
      );
    } else if (savedLocation.city != null) {
      await _loadCity(savedLocation.city!, persist: false);
    }
  }

  Future<bool> _showLocationChoice({
    bool requiredSelection = false,
    bool showSuccess = false,
  }) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      isDismissible: !requiredSelection,
      enableDrag: !requiredSelection,
      showDragHandle: true,
      builder: (context) => const LocationSelectionSheet(),
    );
    if (!mounted) return false;
    var completed = false;
    if (choice == 'automatic') {
      completed = await _useCurrentLocation();
    } else if (choice == 'manual') {
      completed = await _showCityPicker();
    }
    if (completed && showSuccess && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Konum güncellendi.')));
    }
    if (!completed && requiredSelection && mounted) {
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => _showLocationChoice(requiredSelection: true),
      );
    }
    return completed;
  }

  Future<bool> _useCurrentLocation() async {
    setState(() {
      _loading = true;
      _error = null;
      _location = 'Konum bulunuyor…';
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw const LocationServiceDisabledException();
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied) {
        throw Exception('Konum izni verilmedi.');
      }
      if (permission == LocationPermission.deniedForever) {
        throw Exception('Konum izni kalıcı olarak reddedildi.');
      }
      Position? position = await Geolocator.getLastKnownPosition();
      final cachedPositionIsFresh =
          position != null &&
          DateTime.now().difference(position.timestamp).inMinutes < 30;
      if (!cachedPositionIsFresh) {
        try {
          position = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.medium,
              timeLimit: Duration(seconds: 12),
            ),
          );
        } on TimeoutException {
          // Eski de olsa son bilinen konum, hiç konum olmamasından daha iyidir.
        }
      }
      if (position == null) {
        throw Exception('Konum verisi bulunamadı.');
      }
      final result = await _api.byCoordinates(
        position.latitude,
        position.longitude,
      );
      _applyResult(result, 'Mevcut konum');
      await _storage.saveAutomaticLocation(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      return true;
    } catch (error) {
      if (!mounted) return false;
      final message = error is LocationServiceDisabledException
          ? 'Cihazın konum servisi kapalı. Konumu açın veya şehir seçin.'
          : error.toString().contains('kalıcı')
          ? 'Konum izni kalıcı olarak reddedildi. Ayarlardan izin verebilir veya şehir seçebilirsiniz.'
          : error.toString().contains('reddedildi')
          ? 'Konum izni reddedildi. Şehrinizi manuel seçebilirsiniz.'
          : 'Emülatörden konum alınamadı. Extended controls > Location bölümünden konum gönderin.';
      setState(() {
        _loading = false;
        _error = message;
        _location = 'Konum seçilemedi';
      });
      return _showCityPicker();
    }
  }

  Future<bool> _loadCoordinates(
    double latitude,
    double longitude, {
    bool persist = true,
  }) async {
    setState(() {
      _loading = true;
      _error = null;
      _location = 'Mevcut konum';
    });
    try {
      final result = await _api.byCoordinates(latitude, longitude);
      _applyResult(result, 'Mevcut konum');
      if (persist) {
        await _storage.saveAutomaticLocation(
          latitude: latitude,
          longitude: longitude,
        );
      }
      return true;
    } catch (_) {
      if (!mounted) return false;
      setState(() {
        _loading = false;
        _error = _times.isNotEmpty
            ? 'İnternet bağlantısı yok. Son güncellenen vakitler gösteriliyor.'
            : 'Vakitler alınamadı. İnternet bağlantınızı kontrol edin.';
      });
      return false;
    }
  }

  Future<bool> _loadCity(String city, {bool persist = true}) async {
    setState(() {
      _loading = true;
      _error = null;
      _location = city;
    });
    try {
      final result = await _api.byCity(city);
      _applyResult(result, city);
      if (persist) {
        await _storage.saveManualLocation(
          city: city,
          latitude: result.latitude,
          longitude: result.longitude,
        );
      }
      return true;
    } catch (_) {
      if (!mounted) return false;
      setState(() {
        _loading = false;
        _error = _times.isNotEmpty
            ? 'İnternet bağlantısı yok. Son güncellenen vakitler gösteriliyor.'
            : 'Vakitler alınamadı. İnternet bağlantınızı kontrol edin.';
      });
      return false;
    }
  }

  void _applyResult(PrayerResult result, String location) {
    if (!mounted) return;
    setState(() {
      _times = result.times;
      _date = result.date;
      _hijriDate = result.hijriDate;
      _latitude = result.latitude;
      _longitude = result.longitude;
      _location = location;
      _loading = false;
      _error = null;
    });
    _updateCountdown();
    unawaited(
      _storage.savePrayerCache({
        'times': result.times,
        'date': result.date,
        'hijriDate': result.hijriDate,
        'latitude': result.latitude,
        'longitude': result.longitude,
        'location': location,
        'updatedAt': DateTime.now().toIso8601String(),
      }),
    );
  }

  void _restoreCache(Map<String, dynamic> cache) {
    final rawTimes = cache['times'];
    if (rawTimes is! Map) return;
    setState(() {
      _times = rawTimes.map(
        (key, value) => MapEntry(key.toString(), value.toString()),
      );
      _date = cache['date']?.toString() ?? _date;
      _hijriDate = cache['hijriDate']?.toString() ?? _hijriDate;
      _latitude = (cache['latitude'] as num?)?.toDouble();
      _longitude = (cache['longitude'] as num?)?.toDouble();
      _location = cache['location']?.toString() ?? _location;
    });
    _updateCountdown();
  }

  void _updateCountdown() {
    if (_times.isEmpty || !mounted) return;
    final now = DateTime.now();
    DateTime? next;
    String name = '';
    for (final entry in _times.entries) {
      final parts = entry.value.split(':');
      var candidate = DateTime(
        now.year,
        now.month,
        now.day,
        int.parse(parts[0]),
        int.parse(parts[1]),
      );
      if (candidate.isAfter(now) &&
          (next == null || candidate.isBefore(next))) {
        next = candidate;
        name = entry.key;
      }
    }
    if (next == null) {
      final parts = _times['İmsak']!.split(':');
      next = DateTime(
        now.year,
        now.month,
        now.day + 1,
        int.parse(parts[0]),
        int.parse(parts[1]),
      );
      name = 'İmsak (yarın)';
    }
    setState(() {
      _nextPrayer = name;
      _remaining = next!.difference(now);
    });
  }

  Future<bool> _showCityPicker() async {
    final city = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => const _CityPickerSheet(cities: _cities),
    );
    if (city != null && mounted) {
      return _loadCity(city);
    }
    return false;
  }

  String get _countdown {
    String two(int value) => value.toString().padLeft(2, '0');
    final hours = _remaining.inHours;
    final minutes = _remaining.inMinutes.remainder(60);
    final seconds = _remaining.inSeconds.remainder(60);
    return '${two(hours)}:${two(minutes)}:${two(seconds)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            RefreshIndicator(
              color: _green,
              onRefresh: () => _location == 'Mevcut konum'
                  ? _useCurrentLocation()
                  : _loadSelectedCityWithoutPop(),
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  SliverList.list(
                    children: [
                      _ReferenceHeader(
                        location: _location,
                        onLocationTap: _showCityPicker,
                        onQiblaTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => QiblaPage(
                              latitude: _latitude,
                              longitude: _longitude,
                            ),
                          ),
                        ),
                        onMenuTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => SettingsPage(
                              onUpdateLocation: () =>
                                  _showLocationChoice(showSuccess: true),
                            ),
                          ),
                        ),
                      ),
                      _DateHero(apiDate: _date, hijriDate: _hijriDate),
                      if (_error != null)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
                          child: Text(
                            _error!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color(0xff9a3f35),
                              fontSize: 12.5,
                              fontWeight: FontWeight.w500,
                              height: 1.35,
                            ),
                          ),
                        ),
                      _RemainingRow(
                        prayer: _nextPrayer,
                        countdown: _countdown,
                        loading: _loading,
                      ),
                      _DailyContentSection(content: _dailyContent),
                      if (_times.isEmpty && !_loading)
                        _EmptyState(onTap: _showLocationChoice)
                      else
                        _PrayerStrip(
                          times: _times,
                          names: _prayerInfo.keys.toList(),
                          currentPrayer: _highlightedPrayer,
                        ),
                    ],
                  ),
                  const SliverFillRemaining(
                    hasScrollBody: false,
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: _HomeFooter(),
                    ),
                  ),
                ],
              ),
            ),
            if (_loading)
              const Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: LinearProgressIndicator(
                  color: _green,
                  backgroundColor: Color(0xffebe7dd),
                  minHeight: 1.5,
                ),
              ),
          ],
        ),
      ),
    );
  }

  String? get _currentPrayer {
    if (_times.isEmpty) return null;
    final now = DateTime.now();
    String? current;
    for (final entry in _times.entries) {
      final p = entry.value.split(':');
      final time = DateTime(
        now.year,
        now.month,
        now.day,
        int.parse(p[0]),
        int.parse(p[1]),
      );
      if (!time.isAfter(now)) current = entry.key;
    }
    return current;
  }

  String? get _highlightedPrayer {
    if (_nextPrayer.startsWith('İmsak')) return 'İmsak';
    return _times.containsKey(_nextPrayer) ? _nextPrayer : _currentPrayer;
  }

  Future<void> _loadSelectedCityWithoutPop() async {
    if (!_cities.contains(_location)) return;
    setState(() => _loading = true);
    try {
      _applyResult(await _api.byCity(_location), _location);
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = _times.isNotEmpty
              ? 'İnternet bağlantısı yok. Son güncellenen vakitler gösteriliyor.'
              : 'Vakitler alınamadı. İnternet bağlantınızı kontrol edin.';
        });
      }
    }
  }
}

class _HomeFooter extends StatelessWidget {
  const _HomeFooter();

  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.fromLTRB(24, 26, 24, 18),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'Vesile Takvimi 1.0.0 · DevTayfa',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xff8c887f),
            fontSize: 11.5,
            fontWeight: FontWeight.w600,
            letterSpacing: .2,
          ),
        ),
        SizedBox(height: 8),
        Text(
          'Diyanet hesaplama yöntemi kullanılır. AlAdhan tarafından deneysel olarak sunulduğu için resmî vakitlerden birkaç dakika farklı olabilir.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Color(0xff8c887f), fontSize: 11, height: 1.4),
        ),
      ],
    ),
  );
}

class PrayerApi {
  static const _base = 'api.aladhan.com';

  Future<PrayerResult> byCity(String city) => _request(
    Uri.https(_base, '/v1/timingsByCity', {
      'city': city,
      'country': 'Turkey',
      'method': '13',
    }),
  );

  Future<PrayerResult> byCoordinates(double lat, double lng) => _request(
    Uri.https(_base, '/v1/timings', {
      'latitude': lat.toString(),
      'longitude': lng.toString(),
      'method': '13',
    }),
  );

  Future<PrayerResult> _request(Uri uri) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 10);
    try {
      final request = await client.getUrl(uri);
      request.headers.set(HttpHeaders.userAgentHeader, 'VesileTakvimi/1.0');
      final response = await request.close();
      if (response.statusCode != 200) throw const HttpException('API hatası');
      final body = await response.transform(utf8.decoder).join();
      final json = jsonDecode(body) as Map<String, dynamic>;
      final data = json['data'] as Map<String, dynamic>;
      final timings = data['timings'] as Map<String, dynamic>;
      final date = data['date'] as Map<String, dynamic>;
      final meta = data['meta'] as Map<String, dynamic>;
      final hijri = date['hijri'] as Map<String, dynamic>;
      final month = hijri['month'] as Map<String, dynamic>;
      return PrayerResult(
        times: {
          'İmsak': _clean(timings['Imsak']),
          'Güneş': _clean(timings['Sunrise']),
          'Öğle': _clean(timings['Dhuhr']),
          'İkindi': _clean(timings['Asr']),
          'Akşam': _clean(timings['Maghrib']),
          'Yatsı': _clean(timings['Isha']),
        },
        date: date['readable'].toString(),
        hijriDate:
            '${hijri['day']} ${month['en']} ${hijri['year']} · Hicri Takvim',
        latitude: (meta['latitude'] as num).toDouble(),
        longitude: (meta['longitude'] as num).toDouble(),
      );
    } finally {
      client.close(force: true);
    }
  }

  String _clean(dynamic value) => value.toString().split(' ').first;
}

class PrayerResult {
  const PrayerResult({
    required this.times,
    required this.date,
    required this.hijriDate,
    required this.latitude,
    required this.longitude,
  });
  final Map<String, String> times;
  final String date;
  final String hijriDate;
  final double latitude;
  final double longitude;
}

class LocationSelectionSheet extends StatelessWidget {
  const LocationSelectionSheet({super.key});

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(
              Icons.mosque_outlined,
              size: 42,
              color: Color(0xff9c8455),
            ),
            const SizedBox(height: 14),
            Text(
              'Vakitleri nasıl bulalım?',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            const Text(
              'Bulunduğunuz yere göre doğru namaz vakitlerini gösterebilmemiz için bir yöntem seçin.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xff5f746a), height: 1.45),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: () => Navigator.pop(context, 'automatic'),
              icon: const Icon(Icons.my_location),
              label: const Text('Konumumu otomatik bul'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15),
                backgroundColor: const Color(0xff9c8455),
              ),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () => Navigator.pop(context, 'manual'),
              icon: const Icon(Icons.location_city_outlined),
              label: const Text('Şehri manuel seç'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key, required this.onUpdateLocation});

  final Future<bool> Function() onUpdateLocation;

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xfffffef9),
    appBar: AppBar(
      backgroundColor: const Color(0xfffffef9),
      foregroundColor: const Color(0xff1e1a17),
      iconTheme: const IconThemeData(color: Color(0xff1e1a17)),
      surfaceTintColor: Colors.transparent,
      title: const Text('Ayarlar'),
      actions: [
        IconButton(
          tooltip: 'Konumu Güncelle',
          icon: const Icon(Icons.my_location_outlined),
          onPressed: () async {
            await onUpdateLocation();
          },
        ),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Card(
          elevation: 0,
          color: const Color(0xfff5f1e8),
          child: ListTile(
            leading: const Icon(
              Icons.location_on_outlined,
              color: Color(0xff9c8455),
            ),
            title: const Text('Konumu Güncelle'),
            subtitle: const Text(
              'Otomatik konum veya şehir seçimini yeniden yap.',
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              await onUpdateLocation();
            },
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          elevation: 0,
          color: Color(0xfff5f1e8),
          child: ListTile(
            leading: Icon(Icons.info_outline, color: Color(0xff9c8455)),
            title: Text(
              'Vesile Takvimi',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text(
              'Sürüm 1.0.0 · DevTayfa\nDiyanet hesaplama yöntemi kullanılır.',
            ),
          ),
        ),
        const SizedBox(height: 22),
        Text(
          'Hakkında ve Yasal',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 10),
        Card(
          elevation: 0,
          color: const Color(0xfff5f1e8),
          child: Column(
            children: [
              _LegalTile(
                icon: Icons.info_outline_rounded,
                title: 'Vesile Takvimi Hakkında',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const AboutVesilePage(),
                  ),
                ),
              ),
              const Divider(height: 1, indent: 56),
              _LegalTile(
                icon: Icons.privacy_tip_outlined,
                title: 'Gizlilik Politikası',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const PrivacyPolicyPage(),
                  ),
                ),
              ),
              const Divider(height: 1, indent: 56),
              _LegalTile(
                icon: Icons.balance_outlined,
                title: 'Açık Kaynak Lisansı',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const OpenSourceLicensePage(),
                  ),
                ),
              ),
              const Divider(height: 1, indent: 56),
              _LegalTile(
                icon: Icons.verified_outlined,
                title: 'Marka ve Logo Kullanımı',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const TrademarkPage(),
                  ),
                ),
              ),
              _LegalTile(
                icon: Icons.shop_outlined,
                title: 'Google Play’deki Uygulamalar',
                onTap: () => _openExternal(
                  context,
                  'https://play.google.com/store/apps/dev?id=9056716943737829968&hl=tr',
                ),
              ),
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(14, 22, 14, 28),
          child: Text(
            '© 2026 DevTayfa. Vesile Takvimi adı, logosu ve görsel kimliği '
            'açık kaynak lisansına dahil değildir.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xff70695d),
              fontSize: 12.5,
              height: 1.45,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    ),
  );
}

class _LegalTile extends StatelessWidget {
  const _LegalTile({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
    leading: Icon(icon, color: const Color(0xff9c8455)),
    title: Text(
      title,
      style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600),
    ),
    trailing: const Icon(Icons.chevron_right_rounded),
    onTap: onTap,
  );
}

Future<void> _openExternal(BuildContext context, String value) async {
  final uri = Uri.parse(value);
  var opened = false;
  try {
    opened = await launchUrl(uri, mode: LaunchMode.platformDefault);
    if (!opened) {
      opened = await launchUrl(uri, mode: LaunchMode.inAppBrowserView);
    }
  } catch (_) {
    opened = false;
  }
  if (!opened && context.mounted) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Bağlantı açılamadı.')));
  }
}

class AboutVesilePage extends StatelessWidget {
  const AboutVesilePage({super.key});

  @override
  Widget build(BuildContext context) => _LegalScaffold(
    title: 'Vesile Takvimi Hakkında',
    child: Column(
      children: [
        Image.asset(
          'assets/images/vesile_logo_transparent.png',
          width: 150,
          height: 150,
          errorBuilder: (context, error, stackTrace) => const Icon(
            Icons.mosque_outlined,
            size: 96,
            color: Color(0xffb18d4f),
          ),
        ),
        const SizedBox(height: 12),
        Text('Vesile Takvimi', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 5),
        const Text(
          'Sürüm 1.0.0 · Geliştirici: DevTayfa',
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 20),
        const Text(
          'Vesile Takvimi; namaz vakitlerini, günlük kaynaklı dini içeriği '
          've gerçek zamanlı kıble yönünü sade bir arayüzde sunar.\n\n'
          'Namaz vakitlerinde AlAdhan üzerindeki Diyanet hesaplama yöntemi '
          'kullanılır. Son başarılı vakitler çevrimdışı kullanım için '
          'cihazda saklanır.\n\n'
          'Kaynak kod GPL-3.0 kapsamındadır. Vesile Takvimi adı, logosu, '
          'uygulama ikonu ve görsel kimliği açık kaynak lisansına dahil '
          'değildir.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 15,
            height: 1.6,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 20),
        _AboutLinkBox(
          icon: Icons.language_rounded,
          title: 'DevTayfa',
          subtitle: 'Resmî web sitesini aç',
          onTap: () => _openExternal(context, 'https://devtayfa.com'),
        ),
        const SizedBox(height: 10),
        _AboutLinkBox(
          icon: Icons.code_rounded,
          title: 'GitHub',
          subtitle: 'Açık kaynak profilini aç',
          onTap: () => _openExternal(context, 'https://github.com/umtylmzl'),
        ),
        const SizedBox(height: 10),
        _AboutLinkBox(
          icon: Icons.shop_outlined,
          title: 'Google Play',
          subtitle: 'DevTayfa uygulamalarını aç',
          onTap: () => _openExternal(
            context,
            'https://play.google.com/store/apps/dev?id=9056716943737829968&hl=tr',
          ),
        ),
      ],
    ),
  );
}

class _AboutLinkBox extends StatelessWidget {
  const _AboutLinkBox({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(12),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xfffffef9),
        border: Border.all(color: const Color(0xffd8d1c6)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xffa78653)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Color(0xff5f564c),
                    fontSize: 12.5,
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.open_in_new_rounded, size: 18),
        ],
      ),
    ),
  );
}

class TrademarkPage extends StatelessWidget {
  const TrademarkPage({super.key});

  @override
  Widget build(BuildContext context) => _LegalScaffold(
    title: 'Marka ve Logo Kullanımı',
    child: const SelectableText(
      'Vesile Takvimi adı, logosu, uygulama ikonu ve özgün görsel kimliği '
      'DevTayfa’ya aittir; GPL-3.0 açık kaynak lisansına dahil değildir.\n\n'
      'Kaynak kod GPL-3.0 kapsamında kullanılabilir, değiştirilebilir ve '
      'dağıtılabilir. Ancak üçüncü kişilerce yayımlanan sürümlerde Vesile '
      'Takvimi adı, logosu, paket adı veya DevTayfa tarafından onaylanmış '
      'izlenimi kullanılamaz.\n\n'
      'Ad ve logo kullanımı için DevTayfa’dan önceden yazılı izin alınması '
      'gerekir.\n\n© 2026 DevTayfa. Marka ve görsel kimlik hakları saklıdır.',
      style: TextStyle(
        color: Color(0xff27231b),
        fontSize: 15,
        height: 1.6,
        fontWeight: FontWeight.w500,
      ),
    ),
  );
}

class PrivacyPolicyPage extends StatelessWidget {
  const PrivacyPolicyPage({super.key});

  @override
  Widget build(BuildContext context) => _LegalScaffold(
    title: 'Gizlilik Politikası ve KVKK',
    child: FutureBuilder<String>(
      future: rootBundle.loadString('assets/legal/PRIVACY.md'),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Text(
            'Gizlilik politikası yüklenemedi.',
            style: TextStyle(color: Color(0xff9a3f35)),
          );
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final text = snapshot.data!
            .replaceAll(RegExp(r'^#{1,3}\s*', multiLine: true), '')
            .replaceAll(RegExp(r'^\-\s+', multiLine: true), '• ');
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SelectableText(
              text,
              style: const TextStyle(
                color: Color(0xff27231b),
                fontSize: 14.5,
                height: 1.62,
                fontWeight: FontWeight.w400,
              ),
            ),
            const SizedBox(height: 20),
            OutlinedButton.icon(
              onPressed: () => _openExternal(
                context,
                'https://devtayfa.com/mesafeli-satis-sozlesmesi',
              ),
              icon: const Icon(Icons.description_outlined),
              label: const Text('Mesafeli Satış Sözleşmesi'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => _openExternal(
                context,
                'https://devtayfa.com/iptal-iade-kosullari',
              ),
              icon: const Icon(Icons.assignment_return_outlined),
              label: const Text('İptal ve İade Koşulları'),
            ),
          ],
        );
      },
    ),
  );
}

class OpenSourceLicensePage extends StatelessWidget {
  const OpenSourceLicensePage({super.key});

  @override
  Widget build(BuildContext context) => _LegalScaffold(
    title: 'Açık Kaynak Lisansı',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'GPL-3.0 Lisans Özeti',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 14),
        const Text(
          'Vesile Takvimi kaynak kodu GPL-3.0 kapsamında açık kaynak olarak '
          'sunulmaktadır. Kodu kullanabilir, inceleyebilir, değiştirebilir ve '
          'aynı lisans koşullarıyla dağıtabilirsiniz. Dağıtılan türevlerde '
          'kaynak kod erişilebilir olmalı ve telif/lisans bildirimleri '
          'korunmalıdır.\n\n'
          'Vesile Takvimi adı, logosu, uygulama ikonu ve özgün görsel kimliği '
          'GPL-3.0 kapsamına dahil değildir. Bunların kullanımı için '
          'DevTayfa’nın yazılı izni gerekir.',
          style: TextStyle(
            fontSize: 15,
            height: 1.6,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 22),
        OutlinedButton.icon(
          onPressed: () => _openExternal(
            context,
            'https://www.gnu.org/licenses/gpl-3.0.html',
          ),
          icon: const Icon(Icons.open_in_new_rounded),
          label: const Text('GPL-3.0 tam lisansını aç'),
        ),
        const SizedBox(height: 14),
        TextButton.icon(
          onPressed: () =>
              _openExternal(context, 'https://github.com/umtylmzl'),
          icon: const Icon(Icons.code_rounded),
          label: const Text('GitHub profilini aç'),
        ),
      ],
    ),
  );
}

class _LegalScaffold extends StatelessWidget {
  const _LegalScaffold({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xfffffef9),
    appBar: AppBar(
      title: Text(title),
      backgroundColor: const Color(0xfffffef9),
      foregroundColor: const Color(0xff1e1a17),
      iconTheme: const IconThemeData(color: Color(0xff1e1a17)),
      surfaceTintColor: Colors.transparent,
    ),
    body: ListView(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 32),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xfff5f1e8),
            borderRadius: BorderRadius.circular(18),
          ),
          child: child,
        ),
      ],
    ),
  );
}

class _CityPickerSheet extends StatefulWidget {
  const _CityPickerSheet({required this.cities});

  final List<String> cities;

  @override
  State<_CityPickerSheet> createState() => _CityPickerSheetState();
}

class _CityPickerSheetState extends State<_CityPickerSheet> {
  late final TextEditingController _controller;
  late List<String> _filtered;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
    _filtered = List<String>.from(widget.cities);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _filter(String value) {
    final query = value.toLowerCase();
    setState(() {
      _filtered = widget.cities
          .where((city) => city.toLowerCase().contains(query))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) => AnimatedPadding(
    duration: const Duration(milliseconds: 180),
    curve: Curves.easeOut,
    padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
    child: SafeArea(
      top: false,
      child: LayoutBuilder(
        builder: (context, constraints) => SizedBox(
          height: constraints.maxHeight * .88,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
            child: Column(
              children: [
                Text(
                  'Şehir seçin',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _controller,
                  autofocus: true,
                  decoration: const InputDecoration(
                    hintText: 'Şehir ara…',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                  ),
                  onChanged: _filter,
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.separated(
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    itemCount: _filtered.length,
                    separatorBuilder: (_, _) => const Divider(height: 1),
                    itemBuilder: (_, index) => ListTile(
                      leading: const Icon(
                        Icons.location_on_outlined,
                        color: Color(0xff9c8455),
                      ),
                      title: Text(_filtered[index]),
                      onTap: () => Navigator.pop(context, _filtered[index]),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}

class QiblaPage extends StatefulWidget {
  const QiblaPage({super.key, this.latitude, this.longitude});

  final double? latitude;
  final double? longitude;

  @override
  State<QiblaPage> createState() => _QiblaPageState();
}

class _QiblaPageState extends State<QiblaPage> {
  static const _kaabaLatitude = 21.4225;
  static const _kaabaLongitude = 39.8262;
  StreamSubscription<CompassEvent>? _compassSubscription;
  Timer? _sensorTimer;
  double? _heading;
  double? _bearing;
  double _declination = 0;
  double? _sensorAccuracy;
  String? _error;
  bool _loadingLocation = false;

  @override
  void initState() {
    super.initState();
    if (widget.latitude != null && widget.longitude != null) {
      _setCoordinates(widget.latitude!, widget.longitude!);
    } else {
      _resolveLocation();
    }
    _compassSubscription = FlutterCompass.events?.listen((event) {
      if (!mounted || event.heading == null) return;
      final trueHeading = (event.heading! + _declination + 360) % 360;
      setState(() {
        _heading = _smoothHeading(_heading, trueHeading);
        _sensorAccuracy = event.accuracy;
        if (_error == 'Bu cihazda pusula sensörü bulunamadı.') _error = null;
      });
    });
    _sensorTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && _heading == null) {
        setState(() => _error = 'Bu cihazda pusula sensörü bulunamadı.');
      }
    });
  }

  @override
  void dispose() {
    _sensorTimer?.cancel();
    _compassSubscription?.cancel();
    super.dispose();
  }

  Future<void> _resolveLocation() async {
    setState(() {
      _loadingLocation = true;
      _error = null;
    });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw const LocationServiceDisabledException();
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied) {
        throw Exception('Konum izni reddedildi.');
      }
      if (permission == LocationPermission.deniedForever) {
        throw Exception('Konum izni kalıcı olarak reddedildi.');
      }
      Position? position = await Geolocator.getLastKnownPosition();
      final cachedPositionIsFresh =
          position != null &&
          DateTime.now().difference(position.timestamp).inMinutes < 30;
      if (!cachedPositionIsFresh) {
        try {
          position = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.medium,
              timeLimit: Duration(seconds: 12),
            ),
          );
        } on TimeoutException {
          // Kıble hesabında mevcut son konumu yedek olarak kullan.
        }
      }
      if (position == null) throw Exception('Konum bulunamadı.');
      if (!mounted) return;
      setState(() {
        _setCoordinates(position!.latitude, position.longitude);
        _loadingLocation = false;
      });
    } catch (error) {
      if (!mounted) return;
      final message = error is LocationServiceDisabledException
          ? 'Konum servisi kapalı. Kıble hesabı için konumu açın.'
          : error.toString().contains('kalıcı')
          ? 'Konum izni kalıcı olarak reddedildi. Sistem ayarlarından izin verin.'
          : error.toString().contains('reddedildi')
          ? 'Konum izni reddedildi. Kıble hesabı için izin gereklidir.'
          : 'Kıble hesabı için konum alınamadı.';
      setState(() {
        _loadingLocation = false;
        _error = message;
      });
    }
  }

  double _qiblaBearing(double latitude, double longitude) {
    double radians(double degree) => degree * math.pi / 180;
    final userLatitude = radians(latitude);
    final longitudeDifference = radians(_kaabaLongitude - longitude);
    final kaabaLatitude = radians(_kaabaLatitude);
    final y = math.sin(longitudeDifference);
    final x =
        math.cos(userLatitude) * math.tan(kaabaLatitude) -
        math.sin(userLatitude) * math.cos(longitudeDifference);
    return (math.atan2(y, x) * 180 / math.pi + 360) % 360;
  }

  void _setCoordinates(double latitude, double longitude) {
    _bearing = _qiblaBearing(latitude, longitude);
    _declination = GeoMag()
        .calculate(latitude, longitude, 0, DateTime.now())
        .dec;
  }

  double _smoothHeading(double? previous, double next) {
    if (previous == null) return next;
    final shortestDifference = (next - previous + 540) % 360 - 180;
    return (previous + shortestDifference * .22 + 360) % 360;
  }

  double? get _relativeDirection {
    if (_bearing == null || _heading == null) return null;
    return (_bearing! - _heading! + 360) % 360;
  }

  bool get _isAligned {
    final direction = _relativeDirection;
    return direction != null && (direction <= 8 || direction >= 352);
  }

  @override
  Widget build(BuildContext context) {
    final direction = _relativeDirection;
    return Scaffold(
      backgroundColor: const Color(0xfffffef9),
      appBar: AppBar(
        backgroundColor: const Color(0xfffffef9),
        foregroundColor: const Color(0xff1e1a17),
        iconTheme: const IconThemeData(color: Color(0xff1e1a17)),
        surfaceTintColor: Colors.transparent,
        centerTitle: true,
        title: const Text(
          'Kıble',
          style: TextStyle(
            color: Color(0xff171612),
            fontSize: 17,
            fontWeight: FontWeight.w400,
          ),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 22, 24, 32),
          children: [
            const Text(
              'KÂBE YÖNÜ',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xff9c8455),
                fontSize: 11,
                letterSpacing: 2.2,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _bearing == null
                  ? 'Konum bekleniyor'
                  : '${_bearing!.round()}° kuzeyden',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xff171612), fontSize: 15),
            ),
            const SizedBox(height: 32),
            Center(
              child: SizedBox(
                width: 300,
                height: 300,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Transform.rotate(
                      angle: -((_heading ?? 0) * math.pi / 180),
                      child: const CustomPaint(
                        size: Size.square(300),
                        painter: _CompassDialPainter(),
                      ),
                    ),
                    if (direction != null)
                      AnimatedRotation(
                        turns: direction / 360,
                        duration: const Duration(milliseconds: 140),
                        curve: Curves.easeOut,
                        child: const SizedBox(
                          width: 250,
                          height: 250,
                          child: Align(
                            alignment: Alignment.topCenter,
                            child: Icon(
                              Icons.navigation_rounded,
                              size: 58,
                              color: Color(0xff9c8455),
                            ),
                          ),
                        ),
                      ),
                    Container(
                      width: 58,
                      height: 58,
                      decoration: BoxDecoration(
                        color: _isAligned
                            ? const Color(0xff9c8455)
                            : const Color(0xff171612),
                        borderRadius: BorderRadius.circular(9),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x22000000),
                            blurRadius: 12,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.mosque_outlined,
                        color: Colors.white,
                        size: 27,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30),
            Text(
              _isAligned
                  ? 'Kıble yönündesiniz'
                  : _heading == null
                  ? 'Telefonu yatay tutup sekiz çizerek kalibre edin'
                  : 'Altın oku ekranın üstüne hizalayın',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _isAligned
                    ? const Color(0xff9c8455)
                    : const Color(0xff302d27),
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _heading == null
                  ? 'Pusula verisi bekleniyor…'
                  : 'Gerçek kuzeye göre ${_heading!.round()}°',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xff807a6f), fontSize: 12),
            ),
            if (_sensorAccuracy != null && _sensorAccuracy! > 20) ...[
              const SizedBox(height: 10),
              const Text(
                'Pusula doğruluğu düşük. Telefonu yatay tutup sekiz çizerek kalibre edin.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xff9a6b31),
                  fontSize: 12,
                  height: 1.4,
                ),
              ),
            ],
            if (_loadingLocation) ...[
              const SizedBox(height: 20),
              const LinearProgressIndicator(
                minHeight: 1.5,
                color: Color(0xff9c8455),
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color: const Color(0xfff4f0e7),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xff6f6044),
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _CompassDialPainter extends CustomPainter {
  const _CompassDialPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2;
    final circlePaint = Paint()
      ..color = const Color(0xffd8d2c5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawCircle(center, radius - 2, circlePaint);
    canvas.drawCircle(center, radius - 17, circlePaint);

    for (var degree = 0; degree < 360; degree += 5) {
      final angle = (degree - 90) * math.pi / 180;
      final major = degree % 30 == 0;
      final startRadius = radius - (major ? 29 : 23);
      final tickPaint = Paint()
        ..color = major ? const Color(0xff5d574c) : const Color(0xffbbb4a5)
        ..strokeWidth = major ? 1.4 : .7;
      canvas.drawLine(
        center +
            Offset(
              math.cos(angle) * startRadius,
              math.sin(angle) * startRadius,
            ),
        center +
            Offset(
              math.cos(angle) * (radius - 8),
              math.sin(angle) * (radius - 8),
            ),
        tickPaint,
      );
    }

    const labels = {'K': -90.0, 'D': 0.0, 'G': 90.0, 'B': 180.0};
    for (final entry in labels.entries) {
      final angle = entry.value * math.pi / 180;
      final point =
          center +
          Offset(
            math.cos(angle) * (radius - 49),
            math.sin(angle) * (radius - 49),
          );
      final painter = TextPainter(
        text: TextSpan(
          text: entry.key,
          style: TextStyle(
            color: entry.key == 'K'
                ? const Color(0xff9c8455)
                : const Color(0xff302d27),
            fontFamily: 'serif',
            fontSize: 16,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      painter.paint(
        canvas,
        point - Offset(painter.width / 2, painter.height / 2),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ReferenceHeader extends StatelessWidget {
  const _ReferenceHeader({
    required this.location,
    required this.onLocationTap,
    required this.onQiblaTap,
    required this.onMenuTap,
  });

  final String location;
  final VoidCallback onLocationTap;
  final VoidCallback onQiblaTap;
  final VoidCallback onMenuTap;

  @override
  Widget build(BuildContext context) {
    final label = location == 'Mevcut konum' ? 'Konumum' : location;
    return SizedBox(
      height: 58,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            left: 12,
            child: IconButton(
              tooltip: 'Kıbleyi bul',
              onPressed: onQiblaTap,
              icon: const Icon(Icons.explore_outlined),
              color: const Color(0xff9c8455),
              iconSize: 21,
              visualDensity: VisualDensity.compact,
            ),
          ),
          Material(
            color: const Color(0xfff7f5f0),
            child: InkWell(
              onTap: onLocationTap,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 11,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xffd8d1c6), width: .7),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 110),
                      child: Text(
                        label,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xff736c5e),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(width: 3),
                    const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      size: 14,
                      color: Color(0xffa99a78),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            right: 12,
            child: IconButton(
              tooltip: 'Ayarlar',
              onPressed: onMenuTap,
              icon: const Icon(Icons.menu_rounded),
              color: const Color(0xff9c8455),
              iconSize: 23,
              visualDensity: VisualDensity.compact,
            ),
          ),
        ],
      ),
    );
  }
}

class _DateHero extends StatelessWidget {
  const _DateHero({required this.apiDate, required this.hijriDate});

  final String apiDate;
  final String hijriDate;

  static const _months = [
    'Ocak',
    'Şubat',
    'Mart',
    'Nisan',
    'Mayıs',
    'Haziran',
    'Temmuz',
    'Ağustos',
    'Eylül',
    'Ekim',
    'Kasım',
    'Aralık',
  ];
  static const _weekdays = [
    'Pazartesi',
    'Salı',
    'Çarşamba',
    'Perşembe',
    'Cuma',
    'Cumartesi',
    'Pazar',
  ];

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final detail = (hijriDate.isEmpty ? apiDate : hijriDate).replaceAll(
      ' · Hicri Takvim',
      '',
    );
    final rumiDate = now.subtract(const Duration(days: 13));
    final rumi =
        '${rumiDate.day} ${_months[rumiDate.month - 1]} ${rumiDate.year - 584}';
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
      child: Column(
        children: [
          SizedBox(
            height: 58,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Transform.translate(
                  offset: const Offset(-18, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        now.day.toString().padLeft(2, '0'),
                        style: const TextStyle(
                          color: Color(0xff1e1a17),
                          fontFamily: 'CormorantGaramond',
                          fontSize: 48,
                          height: .92,
                          fontWeight: FontWeight.w400,
                          letterSpacing: -1.2,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${_months[now.month - 1]} ${now.year}',
                              style: const TextStyle(
                                fontSize: 13.5,
                                color: Color(0xff1e1a17),
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                            Text(
                              _weekdays[now.weekday - 1],
                              style: const TextStyle(
                                fontSize: 13.5,
                                color: Color(0xff1e1a17),
                                height: 1.15,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Hicrî: $detail',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xff5f564c),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Rûmî: $rumi',
                  textAlign: TextAlign.right,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xff5f564c),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RemainingRow extends StatelessWidget {
  const _RemainingRow({
    required this.prayer,
    required this.countdown,
    required this.loading,
  });

  final String prayer;
  final String countdown;
  final bool loading;

  @override
  Widget build(BuildContext context) => Container(
    height: 64,
    padding: const EdgeInsets.symmetric(horizontal: 22),
    decoration: const BoxDecoration(
      border: Border.symmetric(
        horizontal: BorderSide(color: Color(0xffd8d1c6), width: .7),
      ),
    ),
    child: Row(
      children: [
        Expanded(
          child: Text(
            'Kalan Vakit ($prayer)',
            style: const TextStyle(
              color: Color(0xff28251f),
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        Text(
          loading ? '--:--:--' : countdown,
          style: const TextStyle(
            color: Color(0xff151515),
            fontSize: 22,
            fontWeight: FontWeight.w500,
            letterSpacing: -.7,
          ),
        ),
      ],
    ),
  );
}

class _PrayerStrip extends StatefulWidget {
  const _PrayerStrip({
    required this.times,
    required this.names,
    required this.currentPrayer,
  });

  final Map<String, String> times;
  final List<String> names;
  final String? currentPrayer;

  @override
  State<_PrayerStrip> createState() => _PrayerStripState();
}

class _PrayerStripState extends State<_PrayerStrip> {
  late final PageController _controller;

  @override
  void initState() {
    super.initState();
    final activeIndex = widget.names.indexOf(widget.currentPrayer ?? '');
    _controller = PageController(initialPage: activeIndex >= 3 ? 1 : 0);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Container(
    height: 102,
    decoration: const BoxDecoration(
      border: Border.symmetric(
        horizontal: BorderSide(color: Color(0xffd8d1c6), width: .7),
      ),
    ),
    child: PageView.builder(
      controller: _controller,
      itemCount: (widget.names.length / 3).ceil(),
      itemBuilder: (context, pageIndex) {
        final start = pageIndex * 3;
        final pageNames = widget.names.skip(start).take(3).toList();
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: pageNames.map((name) {
              final active = name == widget.currentPrayer;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: active
                          ? const Color(0xffb59663)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          name,
                          maxLines: 1,
                          style: TextStyle(
                            color: active
                                ? Colors.white
                                : const Color(0xff28251f),
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 3),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            widget.times[name] ?? '--:--',
                            style: TextStyle(
                              color: active
                                  ? Colors.white
                                  : const Color(0xff151515),
                              fontSize: 21,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        );
      },
    ),
  );
}

class _DailyContentSection extends StatelessWidget {
  const _DailyContentSection({required this.content});

  final Future<DailyReligiousContent> content;

  @override
  Widget build(BuildContext context) => FutureBuilder<DailyReligiousContent>(
    future: content,
    builder: (context, snapshot) {
      if (!snapshot.hasData) {
        return const SizedBox(
          height: 150,
          child: Center(
            child: CircularProgressIndicator(
              strokeWidth: 1.5,
              color: Color(0xff9c8455),
            ),
          ),
        );
      }
      return _DailyReligiousCard(content: snapshot.data!);
    },
  );
}

class _DailyReligiousCard extends StatelessWidget {
  const _DailyReligiousCard({required this.content});

  final DailyReligiousContent content;

  String get _typeLabel => switch (content.type) {
    'ayet' => 'AYET',
    'hadis' => 'HADİS',
    'dua' => 'DUA',
    _ => 'HİKMET',
  };

  @override
  Widget build(BuildContext context) => Container(
    constraints: const BoxConstraints(minHeight: 210),
    padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
    decoration: const BoxDecoration(
      border: Border(top: BorderSide(color: Color(0xffd8d1c6), width: .7)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            _SectionAction(
              tooltip: 'İçeriği genişlet',
              icon: Icons.fullscreen_rounded,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => _DailyContentDetailPage(content: content),
                ),
              ),
            ),
            const Spacer(),
            _SectionAction(
              tooltip: 'Paylaş',
              icon: Icons.ios_share_outlined,
              onTap: () => SharePlus.instance.share(
                ShareParams(
                  text:
                      '${content.title}\n\n${content.arabic.isEmpty ? '' : '${content.arabic}\n\n'}'
                      '${content.turkish}\n\nKaynak: ${content.source}\n\n'
                      'Vesile Takvimi',
                ),
              ),
            ),
            const SizedBox(width: 18),
            _SectionAction(
              tooltip: 'Kaydet',
              icon: Icons.bookmark_border_rounded,
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('İçerik kaydedildi.')),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Text(
          '$_typeLabel · ${content.title}',
          style: const TextStyle(
            color: Color(0xff1e1a17),
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: .15,
          ),
        ),
        if (content.arabic.trim().isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xfff2eee6),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              content.arabic,
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
              style: const TextStyle(
                color: Color(0xff201d18),
                fontSize: 20,
                height: 1.75,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
        const SizedBox(height: 14),
        Text(
          content.turkish,
          style: const TextStyle(
            color: Color(0xff1e1a17),
            fontSize: 15,
            height: 1.48,
            fontWeight: FontWeight.w400,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.menu_book_outlined,
              color: Color(0xff9c8455),
              size: 15,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                content.source,
                style: const TextStyle(
                  color: Color(0xff625d53),
                  fontSize: 12.5,
                  height: 1.35,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );
}

class _SectionAction extends StatelessWidget {
  const _SectionAction({
    required this.tooltip,
    required this.icon,
    required this.onTap,
  });

  final String tooltip;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Tooltip(
    message: tooltip,
    child: InkResponse(
      onTap: onTap,
      radius: 22,
      child: SizedBox(
        width: 26,
        height: 26,
        child: Icon(icon, size: 20, color: const Color(0xffa78653)),
      ),
    ),
  );
}

class _DailyContentDetailPage extends StatelessWidget {
  const _DailyContentDetailPage({required this.content});

  final DailyReligiousContent content;

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xfff7f5f0),
    appBar: AppBar(
      title: Text(content.title),
      actions: [
        IconButton(
          tooltip: 'Paylaş',
          onPressed: () => SharePlus.instance.share(
            ShareParams(
              text:
                  '${content.title}\n\n${content.arabic.isEmpty ? '' : '${content.arabic}\n\n'}'
                  '${content.turkish}\n\nKaynak: ${content.source}\n\n'
                  'Vesile Takvimi',
            ),
          ),
          icon: const Icon(Icons.ios_share_outlined),
        ),
      ],
    ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (content.arabic.trim().isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xfff2eee6),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                content.arabic,
                textAlign: TextAlign.right,
                textDirection: TextDirection.rtl,
                style: const TextStyle(fontSize: 25, height: 1.85),
              ),
            ),
            const SizedBox(height: 24),
          ],
          Text(
            content.turkish,
            style: const TextStyle(
              color: Color(0xff1e1a17),
              fontSize: 18,
              height: 1.65,
              fontWeight: FontWeight.w400,
            ),
          ),
          const SizedBox(height: 22),
          Text(
            'Kaynak: ${content.source}',
            style: const TextStyle(
              color: Color(0xff5f564c),
              fontSize: 14,
              height: 1.45,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    ),
  );
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.onTap});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 35),
    child: Column(
      children: [
        const Icon(
          Icons.location_searching,
          size: 50,
          color: Color(0xff6cb28e),
        ),
        const SizedBox(height: 12),
        const Text('Vakitleri görmek için konum seçin.'),
        const SizedBox(height: 12),
        OutlinedButton(onPressed: onTap, child: const Text('Konum seç')),
      ],
    ),
  );
}
