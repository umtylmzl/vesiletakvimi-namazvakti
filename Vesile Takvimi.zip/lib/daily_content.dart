import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DailyReligiousContent {
  const DailyReligiousContent({
    required this.type,
    required this.title,
    required this.arabic,
    required this.turkish,
    required this.source,
    this.reference,
    this.fromApi = false,
  });

  final String type;
  final String title;
  final String arabic;
  final String turkish;
  final String source;
  final String? reference;
  final bool fromApi;

  factory DailyReligiousContent.fromJson(
    Map<String, dynamic> json, {
    bool fromApi = false,
  }) => DailyReligiousContent(
    type: json['type'].toString(),
    title: json['title'].toString(),
    arabic: json['arabic'].toString(),
    turkish: json['turkish'].toString(),
    source: json['source'].toString(),
    reference: json['reference']?.toString(),
    fromApi: fromApi,
  );

  Map<String, dynamic> toJson() => {
    'type': type,
    'title': title,
    'arabic': arabic,
    'turkish': turkish,
    'source': source,
    if (reference != null) 'reference': reference,
  };
}

class DailyContentService {
  static const _assetPath = 'assets/data/daily_content.json';
  static const _types = ['ayet', 'hadis', 'dua', 'hikmet'];

  Future<DailyReligiousContent> contentFor(DateTime date) async {
    final normalized = DateTime.utc(date.year, date.month, date.day);
    final dayNumber =
        normalized.millisecondsSinceEpoch ~/ Duration.millisecondsPerDay;
    final type = _types[dayNumber % _types.length];
    final localData = await _loadLocalData();
    final entries = (localData[type] as List).cast<Map<String, dynamic>>();
    final selected = entries[(dayNumber ~/ _types.length) % entries.length];
    final localContent = DailyReligiousContent.fromJson(selected);
    if (type != 'ayet') return localContent;

    final cached = await _loadCachedAyah(normalized);
    if (cached != null) return cached;
    try {
      final apiContent = await _fetchAyah(localContent);
      await _cacheAyah(normalized, apiContent);
      return apiContent;
    } catch (_) {
      return localContent;
    }
  }

  Future<Map<String, dynamic>> _loadLocalData() async {
    final raw = await rootBundle.loadString(_assetPath);
    return jsonDecode(raw) as Map<String, dynamic>;
  }

  Future<DailyReligiousContent> _fetchAyah(
    DailyReligiousContent fallback,
  ) async {
    final reference = fallback.reference;
    if (reference == null) throw const FormatException('Ayet referansı yok.');
    final uri = Uri.https(
      'api.alquran.cloud',
      '/v1/ayah/$reference/editions/quran-uthmani,tr.diyanet',
    );
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final request = await client.getUrl(uri);
      request.headers.set(HttpHeaders.userAgentHeader, 'VesileTakvimi/1.0');
      final response = await request.close().timeout(
        const Duration(seconds: 10),
      );
      if (response.statusCode != 200) {
        throw const HttpException('Ayet API hatası');
      }
      final raw = await response.transform(utf8.decoder).join();
      final body = jsonDecode(raw) as Map<String, dynamic>;
      final data = (body['data'] as List).cast<Map<String, dynamic>>();
      final arabic = data.firstWhere(
        (item) =>
            (item['edition'] as Map<String, dynamic>)['identifier'] ==
            'quran-uthmani',
      );
      final turkish = data.firstWhere(
        (item) =>
            (item['edition'] as Map<String, dynamic>)['identifier'] ==
            'tr.diyanet',
      );
      return DailyReligiousContent(
        type: 'ayet',
        title: fallback.title,
        arabic: arabic['text'].toString(),
        turkish: turkish['text'].toString(),
        source: fallback.source,
        reference: reference,
        fromApi: true,
      );
    } finally {
      client.close(force: true);
    }
  }

  String _dateKey(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-'
      '${date.month.toString().padLeft(2, '0')}-'
      '${date.day.toString().padLeft(2, '0')}';

  Future<DailyReligiousContent?> _loadCachedAyah(DateTime date) async {
    final raw = (await SharedPreferences.getInstance()).getString(
      'daily_ayah_${_dateKey(date)}',
    );
    if (raw == null) return null;
    try {
      return DailyReligiousContent.fromJson(
        jsonDecode(raw) as Map<String, dynamic>,
        fromApi: true,
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> _cacheAyah(DateTime date, DailyReligiousContent content) async {
    await (await SharedPreferences.getInstance()).setString(
      'daily_ayah_${_dateKey(date)}',
      jsonEncode(content.toJson()),
    );
  }
}
