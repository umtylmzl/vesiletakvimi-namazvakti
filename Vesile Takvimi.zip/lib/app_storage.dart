import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class AppStorageService {
  static const onboardingKey = 'onboarding_completed_v1';
  static const legalAcceptanceKey = 'legal_acceptance_completed_v1';
  static const locationCompletedKey = 'location_selection_completed_v1';
  static const locationModeKey = 'selected_location_mode_v1';
  static const cityKey = 'selected_city_v1';
  static const latitudeKey = 'selected_latitude_v1';
  static const longitudeKey = 'selected_longitude_v1';
  static const prayerCacheKey = 'prayer_cache_v1';

  Future<SharedPreferences> get _preferences => SharedPreferences.getInstance();

  Future<bool> isOnboardingCompleted() async =>
      (await _preferences).getBool(onboardingKey) ?? false;

  Future<void> completeOnboarding() async =>
      (await _preferences).setBool(onboardingKey, true);

  Future<bool> isLegalAcceptanceCompleted() async =>
      (await _preferences).getBool(legalAcceptanceKey) ?? false;

  Future<void> completeLegalAcceptance() async =>
      (await _preferences).setBool(legalAcceptanceKey, true);

  Future<bool> isLocationSelectionCompleted() async {
    final preferences = await _preferences;
    return preferences.getBool(locationCompletedKey) == true ||
        preferences.containsKey(cityKey) ||
        (preferences.containsKey(latitudeKey) &&
            preferences.containsKey(longitudeKey));
  }

  Future<SavedLocation?> loadLocation() async {
    final preferences = await _preferences;
    final mode = preferences.getString(locationModeKey);
    final city = preferences.getString(cityKey);
    final latitude = preferences.getDouble(latitudeKey);
    final longitude = preferences.getDouble(longitudeKey);
    if (city == null && (latitude == null || longitude == null)) return null;
    return SavedLocation(
      automatic: mode == 'automatic',
      city: city,
      latitude: latitude,
      longitude: longitude,
    );
  }

  Future<void> saveAutomaticLocation({
    required double latitude,
    required double longitude,
  }) async {
    final preferences = await _preferences;
    await preferences.setString(locationModeKey, 'automatic');
    await preferences.remove(cityKey);
    await preferences.setDouble(latitudeKey, latitude);
    await preferences.setDouble(longitudeKey, longitude);
    await preferences.setBool(locationCompletedKey, true);
  }

  Future<void> saveManualLocation({
    required String city,
    required double latitude,
    required double longitude,
  }) async {
    final preferences = await _preferences;
    await preferences.setString(locationModeKey, 'manual');
    await preferences.setString(cityKey, city);
    await preferences.setDouble(latitudeKey, latitude);
    await preferences.setDouble(longitudeKey, longitude);
    await preferences.setBool(locationCompletedKey, true);
  }

  Future<void> savePrayerCache(Map<String, dynamic> cache) async =>
      (await _preferences).setString(prayerCacheKey, jsonEncode(cache));

  Future<Map<String, dynamic>?> loadPrayerCache() async {
    final raw = (await _preferences).getString(prayerCacheKey);
    if (raw == null) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }
}

class SavedLocation {
  const SavedLocation({
    required this.automatic,
    this.city,
    this.latitude,
    this.longitude,
  });

  final bool automatic;
  final String? city;
  final double? latitude;
  final double? longitude;
}
