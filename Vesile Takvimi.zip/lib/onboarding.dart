import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class OnboardingPageModel {
  const OnboardingPageModel({
    required this.title,
    required this.asset,
    required this.titleColor,
    required this.colors,
  });

  final String title;
  final String asset;
  final Color titleColor;
  final List<Color> colors;
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({
    super.key,
    required this.onCompleted,
    this.startAtLegal = false,
  });

  final Future<void> Function() onCompleted;
  final bool startAtLegal;

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  late final PageController _controller;
  final _legalScrollController = ScrollController();
  late int _page;
  var _finishing = false;
  var _legalRead = false;
  var _legalAccepted = false;

  static const _pages = [
    OnboardingPageModel(
      title: 'Namaz vakitlerine\nbulunduğun konumdan\nanında ulaş.',
      asset: 'assets/illustrations/location_onboarding.svg',
      titleColor: Color(0xff52755f),
      colors: [Color(0xfff7faf2), Color(0xffeff6e8)],
    ),
    OnboardingPageModel(
      title: 'Bulunduğun yerden\nkıble pusulasıyla\nkıbleni kolayca bul.',
      asset: 'assets/illustrations/qibla_onboarding.svg',
      titleColor: Color(0xff3f718f),
      colors: [Color(0xfff1f7fc), Color(0xffe7f1fa)],
    ),
  ];

  @override
  void initState() {
    super.initState();
    _page = widget.startAtLegal ? 2 : 0;
    _controller = PageController(initialPage: _page);
  }

  @override
  void dispose() {
    _controller.dispose();
    _legalScrollController.dispose();
    super.dispose();
  }

  Future<void> _continue() async {
    if (_page < 2) {
      await _controller.animateToPage(
        _page + 1,
        duration: const Duration(milliseconds: 380),
        curve: Curves.easeOutCubic,
      );
      return;
    }
    if (!_legalRead || !_legalAccepted) return;
    if (_finishing) return;
    setState(() => _finishing = true);
    await widget.onCompleted();
    if (mounted) setState(() => _finishing = false);
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: false,
    child: Scaffold(
      backgroundColor: const Color(0xfffffef9),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) => Column(
            children: [
              Expanded(
                child: PageView.builder(
                  controller: _controller,
                  itemCount: _pages.length + 1,
                  onPageChanged: (page) => setState(() => _page = page),
                  itemBuilder: (context, index) => index < _pages.length
                      ? OnboardingCard(model: _pages[index])
                      : _LegalAcceptanceCard(
                          controller: _legalScrollController,
                          readToEnd: _legalRead,
                          accepted: _legalAccepted,
                          onReadToEnd: () {
                            if (!_legalRead) {
                              setState(() => _legalRead = true);
                            }
                          },
                          onAcceptedChanged: (value) =>
                              setState(() => _legalAccepted = value),
                        ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  _pages.length + 1,
                  (index) => AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    width: index == _page ? 20 : 7,
                    height: 7,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      color: index == _page
                          ? const Color(0xffa58b4f)
                          : const Color(0xffddd8cb),
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: OutlinedButton(
                    onPressed:
                        _finishing ||
                            (_page == 2 && (!_legalRead || !_legalAccepted))
                        ? null
                        : _continue,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xff4d432e),
                      side: const BorderSide(
                        color: Color(0xffa58b4f),
                        width: 1.2,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: _finishing
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 1.5),
                          )
                        : Text(
                            _page < 2 ? 'İleri' : 'Kabul Et ve Başla',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
            ],
          ),
        ),
      ),
    ),
  );
}

class LegalAcceptanceScreen extends StatelessWidget {
  const LegalAcceptanceScreen({super.key, required this.onCompleted});

  final Future<void> Function() onCompleted;

  @override
  Widget build(BuildContext context) =>
      OnboardingScreen(onCompleted: onCompleted, startAtLegal: true);
}

class _LegalAcceptanceCard extends StatelessWidget {
  const _LegalAcceptanceCard({
    required this.controller,
    required this.readToEnd,
    required this.accepted,
    required this.onReadToEnd,
    required this.onAcceptedChanged,
  });

  final ScrollController controller;
  final bool readToEnd;
  final bool accepted;
  final VoidCallback onReadToEnd;
  final ValueChanged<bool> onAcceptedChanged;

  static const _legalText =
      'Vesile Takvimi kaynak kodu GPL-3.0 kapsamında açık kaynak olarak '
      'sunulmaktadır. Vesile Takvimi adı, logosu, uygulama ikonu ve özgün '
      'görsel kimliği açık kaynak lisansına dahil değildir. Bunların üçüncü '
      'kişilerce kullanılması için DevTayfa’nın yazılı izni gerekir.\n\n'
      'Uygulama, namaz vakitlerini hesaplamak için seçtiğiniz şehir veya '
      'koordinat bilgisini AlAdhan servisine gönderir. Konum seçiminiz, '
      'tercihleriniz ve son başarılı namaz vakitleri cihazınızda saklanır.\n\n'
      'Konum izni yalnızca bulunduğunuz yere göre vakit ve kıble yönünü '
      'belirlemek için kullanılır. Arka planda konum takibi yapılmaz.\n\n'
      'Devam ederek Gizlilik Politikası, GPL-3.0 lisans koşulları ve Marka '
      've Görsel Kimlik Politikası hakkında bilgilendirildiğinizi kabul '
      'edersiniz.\n\n'
      '© 2026 DevTayfa. Tüm hakları saklıdır.';

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(22, 26, 22, 18),
      decoration: BoxDecoration(
        color: const Color(0xfff7f3e9),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Column(
        children: [
          const Icon(Icons.gavel_outlined, size: 42, color: Color(0xffa58b4f)),
          const SizedBox(height: 10),
          const Text(
            'Hakkında ve Yasal',
            style: TextStyle(
              color: Color(0xff332d20),
              fontSize: 25,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Onay kutusunu açmak için metni sonuna kadar kaydırın.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xff756d5f),
              fontSize: 13,
              height: 1.35,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 14),
          Expanded(
            child: NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                if (notification.metrics.extentAfter <= 2) onReadToEnd();
                return false;
              },
              child: Container(
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: const Color(0xfffffef9),
                  border: Border.all(color: const Color(0xffddd5c4)),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Scrollbar(
                  controller: controller,
                  thumbVisibility: true,
                  child: SingleChildScrollView(
                    controller: controller,
                    child: const Text(
                      _legalText,
                      style: TextStyle(
                        color: Color(0xff27231b),
                        fontSize: 14,
                        height: 1.55,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            activeColor: const Color(0xffa58b4f),
            value: accepted,
            onChanged: readToEnd
                ? (value) => onAcceptedChanged(value ?? false)
                : null,
            title: Text(
              readToEnd
                  ? 'Bilgilendirmeyi okudum ve kabul ediyorum.'
                  : 'Önce metni sonuna kadar kaydırın.',
              style: const TextStyle(
                fontSize: 13.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class OnboardingCard extends StatelessWidget {
  const OnboardingCard({super.key, required this.model});

  final OnboardingPageModel model;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(22, 30, 22, 18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: model.colors,
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [
          BoxShadow(
            color: Color(0x100F2C1F),
            blurRadius: 24,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            model.title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: model.titleColor,
              fontSize: 29,
              height: 1.2,
              fontWeight: FontWeight.w700,
              letterSpacing: -.4,
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: SvgPicture.asset(
              model.asset,
              fit: BoxFit.contain,
              semanticsLabel: model.title,
            ),
          ),
        ],
      ),
    ),
  );
}
