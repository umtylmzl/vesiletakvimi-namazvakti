package com.devtayfa.vesiletakvimi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
