import 'package:flutter_test/flutter_test.dart';
import 'package:namazvaktim/daily_content.dart';
import 'package:namazvaktim/main.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('günün yerel içeriği aynı tarihte sabit kalır', () async {
    SharedPreferences.setMockInitialValues({});
    final service = DailyContentService();
    final date = DateTime(2026, 1, 4);

    final first = await service.contentFor(date);
    final second = await service.contentFor(date);

    expect(first.type, 'hadis');
    expect(second.turkish, first.turkish);
    expect(first.source, isNotEmpty);
  });

  testWidgets('ilk kurulumda tanıtım ve yasal onay gösterilir', (tester) async {
    SharedPreferences.setMockInitialValues({});

    await tester.pumpWidget(const VesileTakvimiApp());
    await tester.pump(const Duration(milliseconds: 1700));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));

    expect(find.textContaining('Namaz vakitlerine'), findsOneWidget);
    expect(find.text('İleri'), findsOneWidget);

    await tester.tap(find.text('İleri'));
    await tester.pumpAndSettle();

    expect(find.textContaining('kıble pusulasıyla'), findsOneWidget);
    expect(find.text('İleri'), findsOneWidget);

    await tester.tap(find.text('İleri'));
    await tester.pumpAndSettle();

    expect(find.text('Hakkında ve Yasal'), findsOneWidget);
    expect(find.text('Kabul Et ve Başla'), findsOneWidget);
  });

  testWidgets('tanıtım tamamlandıysa konum seçimi gösterilir', (tester) async {
    SharedPreferences.setMockInitialValues({
      'onboarding_completed_v1': true,
      'legal_acceptance_completed_v1': true,
    });

    await tester.pumpWidget(const VesileTakvimiApp());
    await tester.pump(const Duration(milliseconds: 1700));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));

    expect(find.text('Vakitleri nasıl bulalım?'), findsOneWidget);
    expect(find.text('Konumumu otomatik bul'), findsOneWidget);
    expect(find.text('Şehri manuel seç'), findsOneWidget);

    await tester.ensureVisible(find.text('Şehri manuel seç'));
    await tester.tap(find.text('Şehri manuel seç'));
    await tester.pump(const Duration(milliseconds: 500));

    expect(find.text('Şehir seçin'), findsOneWidget);
    expect(find.text('Adana'), findsOneWidget);
  });
}
