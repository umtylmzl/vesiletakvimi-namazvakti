# Vesile Takvimi

Vesile Takvimi; konuma veya seçilen şehre göre namaz vakitlerini, günlük kaynaklı dini içeriği ve gerçek zamanlı kıble yönünü gösteren Flutter uygulamasıdır.

## Özellikler

- Otomatik konum ve manuel şehir seçimi
- AlAdhan üzerinden Diyanet hesaplama yöntemi
- Son başarılı namaz vakitlerini çevrimdışı gösterme
- Bir sonraki vakte kalan süre ve yaklaşan vakit vurgusu
- Kaydırılabilir namaz vakitleri
- Gerçek kuzey ve manyetik sapma düzeltmeli kıble pusulası
- Her gece 00:00'da değişen kaynaklı ayet, hadis, dua ve hikmet
- Günlük içeriği tam ekranda okuma ve sistem paylaşımı
- Hicrî ve Rûmî tarih
- Gizlilik/KVKK, GPL-3.0 ve marka politikası sayfaları

## Kurulum

Flutter stable ve Android geliştirme araçları kurulu olmalıdır.

```bash
flutter pub get
flutter run
```

Test ve analiz:

```bash
dart analyze
flutter test
```

Android APK:

```bash
flutter build apk --release
```

## Veri ve gizlilik

Uygulama arka planda sürekli konum takibi yapmaz. Namaz vakitlerinin hesaplanması için seçilen şehir veya koordinat AlAdhan servisine gönderilir. Konum tercihi, son başarılı vakitler ve uygulama tercihleri cihazda yerel olarak saklanır.

Ayrıntılı metin: [`assets/legal/PRIVACY.md`](assets/legal/PRIVACY.md)

## Lisans

Kaynak kod [`GPL-3.0`](LICENSE) kapsamında sunulmaktadır.

“Vesile Takvimi” adı, logo, uygulama ikonu ve özgün görsel kimlik GPL-3.0 kapsamına dahil değildir. Yeniden dağıtım koşulları için [`TRADEMARKS.md`](TRADEMARKS.md) dosyasını inceleyin.

© 2026 DevTayfa.
