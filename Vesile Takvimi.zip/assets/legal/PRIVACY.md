# Gizlilik Politikası ve KVKK Aydınlatma Metni

Son güncelleme: 15 Nisan 2026

## Giriş

İşbu Gizlilik Politikası, veri sorumlusu DevTayfa ("Satıcı") tarafından işletilen internet sitesini ve platformları ziyaret eden veya kullanan kişilerin ("Kullanıcı") kişisel verilerinin 6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca işlenmesine ilişkin usul ve esasları düzenlemektedir.

Kullanıcıların; adı, soyadı, telefon numarası (WhatsApp hattı dahil), e-posta adresi, adres, IP bilgileri ve sipariş detayları gibi kişiyi doğrudan veya dolaylı olarak belirli kılan her türlü bilgi "Kişisel Veri" olarak kabul edilir.

## Madde 1: Veri sorumlusunun kimliği

KVKK uyarınca, kişisel verileriniz veri sorumlusu olarak DevTayfa tarafından aşağıda açıklanan kapsamda işlenebilecektir.

E-posta: devtayfa@gmail.com

Adres: Beyoğlu / İSTANBUL

## Madde 2: Kişisel verilerin işlenme amaçları ve hukuki sebepleri

Verileriniz şu hukuki sebeplerle işlenmektedir:

Sözleşmenin kurulması ve ifası: Kullanıcı kaydı oluşturmak, siparişleri almak, ödeme işlemlerini teyit etmek, yazılım/dijital içerik teslimatını (panel veya e-posta yoluyla) gerçekleştirmek ve satış sonrası teknik destek sunmak. (KVKK madde 5/2-c)

Yasal yükümlülükler: Mali kayıtların tutulması ve yetkili kamu kurumlarından gelen yasal taleplerin karşılanması. (KVKK madde 5/2-ç)

Meşru menfaatler: Platform güvenliğinin sağlanması, suistimallerin (lisans ihlali, tersine mühendislik vb.) önlenmesi ve hizmet kalitesinin artırılması. (KVKK madde 5/2-f)

## Madde 3: Kişisel verilerin aktarılması

Kişisel verileriniz, sadece işin gerektirdiği ölçüde ve yasal sınırlar dahilinde şu taraflarla paylaşılabilir:

- Ödeme işlemlerinin tamamlanması için ilgili ödeme kuruluşları (Shopier, İyzico, PayTR vb.) ve bankalar.
- Ürünlerin barındırılması ve teslimatı için kullanılan hosting/bulut sunucu firmaları.
- Yasal bir uyuşmazlık durumunda avukatlar, danışmanlar ve yetkili adli/idari makamlar.

## Madde 4: Kişisel verilerin toplanma yöntemi

Kişisel verileriniz; üyelik formları, sipariş ekranları, iletişim formları, WhatsApp destek hattı (+62 831-8859-3669), e-posta yazışmaları ve çerezler (cookies) aracılığıyla tamamen veya kısmen otomatik yollarla toplanmaktadır.

## Madde 5: Çerez (cookie) politikası

Platform, kullanıcı deneyimini iyileştirmek ve site trafiğini analiz etmek için çerezler kullanır. Zorunlu çerezler sitenin çalışması için gereklidir. Analitik çerezler ise kullanıcıların siteyi nasıl kullandığını anlamamıza yardımcı olur. Kullanıcı, tarayıcı ayarları veya site altbilgisindeki Çerez tercihleri üzerinden analitik çerezleri reddetme hakkına sahiptir.

## Madde 6: Veri güvenliği

DevTayfa, kişisel verilerin hukuka aykırı olarak işlenmesini ve erişilmesini önlemek amacıyla teknik imkanlar dahilinde gerekli idari ve teknik tedbirleri alır. Sitede SSL sertifikası ve güvenli veri tabanı protokolleri kullanılır. Ancak, gerekli tüm önlemler alınmasına rağmen platforma yapılabilecek siber saldırılar sonucunda verilerin üçüncü kişilerin eline geçmesi durumunda, Satıcı'nın ağır kusuru bulunmadıkça sorumluluğu olmayacaktır.

## Madde 7: İlgili kişinin hakları (KVKK madde 11)

Her kullanıcı, devtayfa@gmail.com adresine başvurarak; verilerinin işlenip işlenmediğini öğrenme, yanlış işlenmişse düzeltilmesini isteme, verilerinin silinmesini talep etme ve uğradığı zararın giderilmesini isteme haklarına sahiptir.

## Madde 8: Özel durumlar ve kurulum bilgileri

### 8.1. Erişim bilgileri

Kullanıcı'nın yazılım kurulumu veya teknik destek için sağladığı hosting, sunucu veya veritabanı erişim bilgileri, yalnızca ilgili işlemin yapılması amacıyla kullanılır ve işlem sonrası saklanmaz. Bu bilgilerin güvenliğinden ve doğruluğundan bizzat Kullanıcı sorumludur.

### 8.2. Teknik veriler

Hata ayıklama ve hizmet kalitesini artırmak amacıyla tarayıcı tipi, işletim sistemi ve site içi hareketler gibi teknik veriler toplanabilir.

### 8.3. Vesile Takvimi uygulaması

Vesile Takvimi, kullanıcının açık seçimine bağlı olarak cihaz konum iznini kullanabilir. Konum bilgisi yalnızca bulunduğunuz yere göre namaz vakitlerini ve kıble yönünü belirlemek amacıyla işlenir. Uygulama arka planda sürekli konum takibi yapmaz.

Namaz vakitlerinin hesaplanması için seçilen şehir bilgisi veya cihazdan alınan enlem ve boylam bilgisi AlAdhan servisine gönderilir. AlAdhan servisinin veri işleme koşulları kendi gizlilik politikasına tabidir.

Otomatik veya manuel konum tercihi, seçilen şehir, son başarılı namaz vakitleri, günlük içerik önbelleği, tanıtım ve yasal bilgilendirme onayı cihazda yerel olarak saklanır. Bu bilgiler uygulamanın çevrimdışı çalışmasını ve kullanıcının tercihlerini korumasını sağlamak amacıyla kullanılır.

Vesile Takvimi uygulaması kullanıcı hesabı oluşturmaz; ad, soyad, telefon, adres veya ödeme bilgisi talep etmez. Uygulama içindeki internet bağlantıları kullanıcı tarafından açıldığında ilgili üçüncü taraf hizmetin koşulları geçerli olur.

## Madde 9: Politika değişiklikleri

DevTayfa, bu Gizlilik Politikası hükümlerini dilediği zaman güncelleyebilir. Güncel metin sitede yayınlandığı andan itibaren geçerlilik kazanır.

## Madde 10: Kabul ve yürürlük

Platform'u kullanan, üye olan veya sipariş veren her kullanıcı; işbu Gizlilik Politikası (KVKK aydınlatması), Mesafeli Satış Sözleşmesi ve İptal ve İade Koşulları'nı okuduğunu ve kabul ettiğini beyan etmiş sayılır.

Mesafeli Satış Sözleşmesi: https://devtayfa.com/mesafeli-satis-sozlesmesi

İptal ve İade Koşulları: https://devtayfa.com/iptal-iade-kosullari
