# Vesile Takvimi Marka ve Görsel Kimlik Politikası

“Vesile Takvimi” adı, uygulama logosu, ikonları ve özgün görsel kimliği DevTayfa’ya aittir ve açık kaynak yazılım lisansının kapsamına dahil değildir.

Kaynak kod GPL-3.0 lisansı kapsamında kullanılabilir, değiştirilebilir ve dağıtılabilir. Ancak değiştirilmiş veya üçüncü kişilerce yayımlanan sürümler:

- “Vesile Takvimi” adını kullanamaz,
- Vesile Takvimi logosunu veya karıştırılabilecek derecede benzerini kullanamaz,
- DevTayfa tarafından yayımlanmış veya onaylanmış izlenimi oluşturamaz,
- Orijinal uygulamayla aynı paket adıyla yayımlanamaz.

Ticari veya ücretsiz yeniden dağıtımlarda uygulama adı, logo, paket adı ve geliştirici bilgileri değiştirilmelidir.

Vesile Takvimi adı ve logosunun kullanımı için önceden yazılı izin alınması gerekir.

İletişim: devtayfa.com

© 2026 DevTayfa. Marka ve görsel kimlik hakları saklıdır.
